# ss <- list(name='I',type='set',form='full',dim=1,uels=uels,val=array(c(1,1,0,0,0)));
# sI <- list(name='I',type='set',form='full',uels=uels,val=array(c(1,1,0,0,0)));

# sI <- list(name='I',type='set',form='full',uels=uels,val=array(c(1:2),c(2,1)));
# sI <- list(name='I',type='set',form='sparse',uels=uels,val=array(c(1:2),c(2,1)));
# sI <- list(name='I',type='set',form='full',uels=uels,val=array(c(1:2)));
# sJ <- list(name='J',type='set',form='full',uels=uels);
# sAll <- list(name='Ix',type='set',uels=uels);
